# Copyright (C) 2024 Apple Inc. All Rights Reserved.
"""Depth Pro CLI and tools."""

from .run import main as run_main  # noqa
